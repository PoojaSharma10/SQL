import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class entry {
	Properties props;
	FileInputStream fln;
	Connection dbConnection;

	entry() throws IOException, SQLException {
		props = new Properties();
		fln = new FileInputStream("dbDetails.properties");
		// TODO LOAD JDBC PROPERTIES FROM FILE SYSYTEM
		props.load(fln);

		// TODO load and register 'JDBC driver'
		String driver = props.getProperty("jdbc.driver");
		// REQUIRED IF JDBC 3 OR BELOW
		// Class.forName(driver);

		// TODO get databse connection using jdbc url
		String url = props.getProperty("jdbc.url");

		dbConnection = DriverManager.getConnection(url);
		System.out.println("Connection Successful?" + (dbConnection != null));
	}

	public void insert(int id, int age, String name) throws SQLException {
		String insertQuery = props.getProperty("jdbc.query.insert");
		try (PreparedStatement insertStatement = dbConnection.prepareStatement(insertQuery)) {
			insertStatement.setInt(1, id);
			insertStatement.setInt(2, age);
			insertStatement.setString(3, name);
			insertStatement.executeUpdate();
		}
	}

	public void display() throws SQLException {
		try (Statement selectStatement = dbConnection.createStatement()) {
			String selectQuery = props.getProperty("jdbc.query.select");
			ResultSet result = selectStatement.executeQuery(selectQuery);
			while (result.next()) {
				String message = result.getInt(1)+"   "+result.getInt(2)+"   "+result.getString(3);
				System.out.println(message);
			}
		}
	}

	public static void main(String[] args) throws ClassNotFoundException, SQLException, IOException {

		// All queries are auoto commit
		/*
		 * Statement insertStatement=null; try{
		 * insertStatement=dbConnection.createStatement(); String
		 * insertQuery=props.getProperty("jdbc.query.insert"); int
		 * rows=insertStatement.executeUpdate(insertQuery);
		 * 
		 * System.out.println(rows+" records is(are) added successfully");
		 * 
		 * } finally { if(insertStatement!=null) insertStatement.close(); }
		 */
		/*
		 * String msg1="Hello, World again"; String msg2="Good afternoon";
		 * String insertQuery ="jdbc.query.insert=insert into messages value('"+
		 * msg1 +"'),('"+ msg2 +"')";
		 */
		/*
		 * String insertQuery =props.getProperty("jdbc.query.insert");
		 * try(PreparedStatement
		 * insertStatement=dbConnection.prepareStatement(insertQuery)) { String
		 * msg="This is java"; insertStatement.setString(1,msg);
		 * insertStatement.executeUpdate(); }
		 */
		entry entr = new entry();
		entr.insert(1, 20, "Pooja");
		entr.insert(2, 21, "Rishika");
		entr.insert(3, 22, "Amay");

		entr.display();
	}

}
